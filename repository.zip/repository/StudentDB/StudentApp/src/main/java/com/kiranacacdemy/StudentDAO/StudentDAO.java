package com.kiranacacdemy.StudentDAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class StudentDAO {
	public static ArrayList<Student>fetchStudent() throws Exception {
	//System.out.println(1);
    Class.forName("com.mysql.cj.jdbc.Driver");
    //System.out.println(2);
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb","root","root");
	//System.out.println(3);
	String sql="select * from studentdb";
	//System.out.println(4);
	Statement statement=connection.createStatement();
	//System.out.println(5);
	ResultSet resultset = statement.executeQuery(sql);
	ArrayList<Student>alstud=new ArrayList<Student>();
	while(resultset.next()){
		int sid=resultset.getInt(1);
		String sname=resultset.getString(2);
		Student student =new Student(sname, sid);
		alstud.add(student);
//		System.out.println("sid >>>"+sid);
//		System.out.println("sname>>>"+sname);
	}
	
	return alstud;
}



	


}
