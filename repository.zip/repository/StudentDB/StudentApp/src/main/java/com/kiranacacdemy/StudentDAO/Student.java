package com.kiranacacdemy.StudentDAO;

public class Student {
	public String sname;
	public int sid;
	public Student(String name, int id) {
		super();
		this.sname = name;
		this.sid = id;
	}
	public String getName() {
		return sname;
	}
	public void setName(String name) {
		this.sname = name;
	}
	public int getId() {
		return sid;
	}
	public void setId(int id) {
		this.sid = id;
	}
	@Override
	public String toString() {
		return "Student [name=" + sname + ", id=" + sid + "]";
	}
	
}
