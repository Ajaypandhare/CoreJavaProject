package com.kiranacademy.controller;
import java.util.ArrayList;

import com.kiranacacdemy.StudentDAO.*;
import com.kiranacademy.StudentService.*;
public class StudentController {
	
	ArrayList<Student> fetchStudent() throws Exception{
		ArrayList<Student> alstud= StudentService.fetchStudent();
		return alstud;
	}



}
