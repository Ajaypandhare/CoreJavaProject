package com.kiranacademy;
import java.util.ArrayList;
import com.kiranacacdemy.StudentDAO.*;
import com.kiranacademy.StudentService.*;
public class StudentAppMain {	
		public static void main(String[] args) throws Exception {
			ArrayList<Student>alstud=StudentService.fetchStudent();
			for (Student student : alstud) {
				//System.out.println(student);
				System.out.println("Name :"+student.sname);
				System.out.println( "Id   :"+student.sid);
			}
			
		}


		
	}


