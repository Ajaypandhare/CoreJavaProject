package com.kiranacademy.StudentService;
import java.util.ArrayList;
import com.kiranacacdemy.StudentDAO.*;
public class StudentService {
	public static ArrayList<Student>fetchStudent() throws Exception{
		ArrayList<Student>alstude=StudentDAO.fetchStudent();
		ArrayList<Student>alStudFilter= new ArrayList<Student>();
		
		for (Student student : alstude) {
			 if(student.sname.startsWith("R")) {
				 
			alStudFilter.add(student);
			//alstude.remove(student);
			//System.out.println(student);
			 }
			
		}
		return alStudFilter;
	}


}
